# CrossPhaseMiner：信号灯周期学习系统

**通过重复观测学习路口信号灯周期，告诉配送机器人"距绿灯还有几秒"**

| 项目 | 内容 |
|------|------|
| 目标 | 缩短配送机器人在人行横道前的等待时间 |
| 方式 | 仅用机器人的视觉观测（10Hz）在线学习信号周期 |
| 核心约束 | 真值（ground truth）只用于评估，绝不用于学习 |
| 概念演示 | `conception/motion/crossphase_concept.gif` |

---

## 1. 概述

### 1.1 问题

配送机器人过人行横道时采取保守策略——"连续看到 5 秒绿灯才通过"。
这种方式安全，但因为不知道信号周期，产生了大量不必要的等待。

### 1.2 洞察

城市交通信号灯遵循**分时段（Time-of-Day, TOD）固定周期计划**：在同一
时段内，同一路口反复执行同一周期。机器人多次经过同一路口并观测信号，
就能**学习**这个周期并**预测**未来的信号状态。

来自现场观测（路口1）的强约束：

| 时段 | 绿灯 | 红灯 | 周期 |
|------|------|------|------|
| 20:27 左右 | **31s** | 119s | 150s |
| 00:11 左右 | **31s** | 109s | 140s |

> **同一路口无论白天夜晚，绿灯时长不变，只有红灯时长随时间变化。**
> 这条约束是系统设计的重要支点（见 §5.4 共享绿灯融合）。

### 1.3 方案

1. 机器人在路口等待时，以 10Hz 记录信号颜色观测；
2. 从观测序列中提取信号跳变时刻（红→绿、绿→红）;
3. 由跳变时刻在线学习周期参数 $(T_{cycle}, T_{red}, \varphi)$;
4. 用学到的模型预测"距下一次绿灯的秒数"。

---

## 2. 核心概念

### 2.1 相位约定（全系统唯一）

信号周期为 $[\text{红}(T_{red}) \to \text{绿}(T_{green})]$，每
$T_{cycle} = T_{red} + T_{green}$ 秒重复一次。$\varphi$（phi_offset）
是**红灯开始时刻**（周期原点）的绝对时间戳：

$$
\mathrm{phase}(t) = (t - \varphi) \bmod T_{cycle}, \qquad
\mathrm{color}(t) = \begin{cases}
\text{RED},   & \mathrm{phase}(t) < T_{red} \\
\text{GREEN}, & \mathrm{phase}(t) \ge T_{red}
\end{cases}
$$

系统所有组件只使用这一套约定，不存在任何坐标转换代码。

### 2.2 观测 → 跳变 → 模型

```
观测序列 (10Hz)          跳变时刻               周期模型
R R R R G R R R   →     红→绿 @ 06:01:59   →   T_cycle = 149.9s
(含 3% 误分类)           红→绿 @ 08:04:29       T_red   = 117.7s
                        红→绿 @ 10:24:29       φ = 最近一次红→绿时刻 − T_red
```

### 2.3 TOD 模型

每个路口按时段（白天/夜晚）各维护一个模型；同时利用"绿灯跨时段恒定"
的现场约束做跨时段融合（§5.4）。

---

## 3. 整体流程

```
┌───────────────────────────────────────────────────────────────┐
│ [第1步] 仿真（cli.simulate）                                   │
│   SignalWorld（真值信号）→ RobotArrivalSimulator               │
│   → observations.csv（机器人观测，3% 误分类）                  │
│   → groundtruth_*.json/csv（真值，仅评估用）                   │
└───────────────────────────────────────────────────────────────┘
                            │
┌───────────────────────────────────────────────────────────────┐
│ [第2步] 在线因果管线（cli.evaluate, pipeline）                 │
│   按时间顺序回放每次到达:                                      │
│     ① 用当前模型（只含过去数据）逐秒预测倒计时                  │
│     ② 与真值对比记录误差        ← 仅评估，不回流模型           │
│     ③ 从本次到达的观测中提取跳变 → 贝叶斯 + UKF 学习          │
└───────────────────────────────────────────────────────────────┘
                            │
┌───────────────────────────────────────────────────────────────┐
│ [第3步] 分析（evaluation + plots）                             │
│   result_summary.png / learner_convergence.png /              │
│   countdown_examples.png / observed_transitions.csv / 日志    │
└───────────────────────────────────────────────────────────────┘
```

**因果性保证**：任何时刻的预测与评估都不使用未来数据
（由测试 `test_causality_no_future_information` 验证）。

---

## 4. 数据格式

### 4.1 observations.csv（机器人观测，输入）

| 字段 | 含义 |
|------|------|
| arrival_id | 到达（等待 episode）编号 |
| robot_id | 机器人标识 |
| timestamp | Unix 时间戳（秒，0.1 精度） |
| intersection_id | 路口标识 |
| color | 观测颜色（RED/GREEN，含 3% 误分类） |
| confidence | 视觉置信度——正常 0.88~0.99，误分类 0.55~0.75 |

### 4.2 PhaseTransition（跳变事件）

| 字段 | 含义 |
|------|------|
| timestamp | 跳变估计时刻——新颜色**首次**出现的时刻（回扣） |
| from_color → to_color | RED→GREEN 或 GREEN→RED |
| episode_start | 本段红灯的开始时刻（用于估计 $T_{red}$) |

### 4.3 PeriodModel（学习到的周期模型）

`T_cycle`, `T_red`, `T_green`, `phi_offset`, `confidence`, `sample_count`

---

## 5. 算法

### 5.1 跳变提取（`core/transitions.py`)

- **去抖**：新颜色持续 $d_{min}=2$ 秒才确认跳变，单帧误分类自动滤除；
- **置信度过滤**：$\mathrm{conf} < 0.8$ 的帧直接忽略（误分类帧天然低置信，
  否则会成对产生假跳变）;
- **时间戳回扣**：确认的跳变记在新颜色首帧时刻，消除确认延迟;
- **红灯起点追踪**：若 episode 中先观测到 GREEN→RED，则该段等待是
  $T_{red}$ 的**精确**样本。

实测质量：**Precision 0.98 / Recall 1.00 / F1 0.99**。

### 5.2 贝叶斯周期学习（`core/learners.py`)

输入：红→绿跳变时刻序列 $\{\tau_i\}$，及等待样本
$w_i = \tau_i - s_i$($s_i$ 为该段红灯起点）。

#### (a) $T_{cycle}$：周期图搜索

机器人不会观测到每一次跳变，因此任意两个观测到的跳变时刻之差都是
周期的整数倍：

$$
d_{ij} = \tau_j - \tau_i \approx k_{ij}\,T, \qquad k_{ij} \in \mathbb{Z}^+
$$

对每个候选周期 $T \in [30, 500]$ 秒（941 点网格）打分：

$$
\hat{k}_d = \max\!\left(1,\ \operatorname{round}\!\left(\tfrac{d}{T}\right)\right), \qquad
e_d(T) = \left| d - \hat{k}_d\,T \right|
$$

$$
\mathrm{score}(T) =
\underbrace{\sum_{e_d < 0.05T} \left(1 - \frac{e_d}{0.05T}\right)}_{\text{软内点：整除越精确得分越高}}
- \underbrace{|D| \cdot \frac{|T - \mu_T|}{\mu_T}}_{\text{偏离先验的惩罚}}
- \underbrace{|D| \cdot (1 - R(T))}_{\text{相位一致性}}
$$

其中相位一致性用圆合成量（circular resultant）度量——真周期下所有
跳变落在同一相位：

$$
R(T) = \left| \frac{1}{n} \sum_{i=1}^{n}
\exp\!\left( \mathrm{i}\,\frac{2\pi\, (\tau_i \bmod T)}{T} \right) \right| \in [0,1]
$$

**次谐波混叠与下界约束**：$T/2, T/3, \dots$ 对差值的整数倍拟合与 $T$
完全一样（相位也一致），仅靠跳变时刻不可区分。但等待时间可以证伪它们：

$$
T \;\ge\; \max_i w_i + 5
$$

（有机器人等过 $W$ 秒红灯，周期就不可能短于 $W$。)精化阶段对内点取均值：

$$
\hat{T} = \operatorname{mean}_{d \in \text{inlier}} \frac{d}{\hat{k}_d}
$$

#### (b) $T_{red}$：均匀分布上界估计

均匀到达假设下，红灯期间到达的等待时间 $w \sim \mathrm{Uniform}(0, T_{red})$。
均匀分布上界的极大似然估计是最大样本，且
$\mathbb{E}[\max] = \frac{n}{n+1} T_{red}$，故取无偏修正：

$$
\hat{T}_{red} = \max_i w_i \cdot \frac{n+1}{n}
$$

#### (c) $\varphi$：相位锚定

红→绿跳变发生在相位 $T_{red}$ 处，因此最近一次跳变给出周期原点：

$$
\varphi = \tau_{last} - \mu_{T_{red}}
$$

锚定在最新跳变上，是因为 $T_{cycle}$ 的微小误差 $\Delta T$ 会随周期数
$N$ 累积成相位漂移 $\Delta T \cdot N$；锚在"现在"附近可使工作点的
预测误差最小。

#### (d) 后验更新：高斯积（每次从头重算）

两个高斯分布之积仍为高斯分布。记先验
$\mathcal N(\mu_0, \sigma_0^2)$ 与似然 $\mathcal N(\hat{x}, \sigma_L^2)$，
则后验为精度（方差倒数）加权：

$$
\mu = \frac{\mu_0/\sigma_0^2 + \hat{x}/\sigma_L^2}
            {1/\sigma_0^2 + 1/\sigma_L^2},
\qquad
\sigma^2 = \frac{1}{1/\sigma_0^2 + 1/\sigma_L^2}
$$

**关键设计：这不是递推滤波。** 每次更新都用**全部历史数据**重新计算
$\hat T$、$\hat T_{red}$，再与**原始先验**
$T_{cycle} \sim \mathcal N(120, 40^2)$（通用先验，不读真值）做一次
融合。早期含混估计既不会锁死搜索范围，也不会冻结后验。

#### (e) 置信度

$$
\mathrm{conf} = \left(1 - e^{-n/5}\right) \cdot e^{-\sigma_T/30}
$$

且样本数 $n \ge 10$ 才允许预测（`is_reliable`)——稀疏样本下后验方差
会虚假塌缩（"自信地错")，实验中曾出现 $T=245$（真值 140）的模型给出
248 秒误差预测的失败案例。

### 5.3 UKF 周期学习（对照）

状态 $x = [T_{cycle},\ T_{red},\ \varphi]^\top$，随机游走过程模型，测量
方程

$$
h(x, k) = \varphi + T_{red} + k \cdot T_{cycle}
$$

其中 $k$ 为整数周期索引，同样的等待时间下界作为状态约束。与贝叶斯并行
运行以比较收敛。实测贝叶斯全面更优：UKF 的周期索引 $k$ 依赖当前状态
估计，受同样的混叠影响，且没有全局周期图可依托。

### 5.4 共享绿灯融合（TOD fusion)

现场约束：**同一路口的绿灯时长跨时段恒定**（不同路口可以不同）。
各时段学习器用自己的 $T_{cycle} - T_{red}$ 投票，方差倒数加权融合：

$$
T_{green} = \frac{\sum_p (T_p - T_{red,p}) / \sigma_p^2}
                 {\sum_p 1 / \sigma_p^2}
$$

再回灌到每个时段：

$$
T_{red}^{(p)} = T_{cycle}^{(p)} - T_{green}
$$

由于 $T_{cycle}$ 的估计精度（周期图，误差 <0.1%）远高于 $T_{red}$
（等待统计，误差数秒），样本稀少的时段（夜晚只有 2~5 次到达）也能获得
精确的红灯参数。融合**按路口**进行，各路口绿灯时长独立。

---

## 6. 在线因果管线（`pipeline/online.py`)

按时间顺序回放到达事件，每次到达执行三步：

1. **预测**：用当前模型（仅含过去到达的数据）逐秒输出倒计时；
   模型与视觉颜色冲突时信任视觉，模型倒计时作废；
2. **评分**：与真值世界对比记录误差，**不回流模型**;
3. **学习**：从本次到达的观测提取跳变，更新两个学习器。

---

## 7. 评估指标与结果

### 7.1 指标定义

| 指标 | 含义 |
|------|------|
| 跳变提取 P/R/F1 | 提取跳变 vs 真值（容差 ±2s) |
| cycle_rel_err | $\lvert \hat T - T \rvert / T$（参数比较） |
| color_err | 颜色预测错误率，**仅在相位锚点 ±30min 窗口内**统计 |
| countdown MAE | 倒计时平均绝对误差（按到达） |

±30min 窗口的物理原因：$\Delta T$ 的周期误差经 $N$ 个周期累积为相位
漂移 $\Delta T \cdot N$。拿一个模型外推一整天（~384 周期）测的是外推
漂移而非预测质量；机器人只在"现在"附近使用模型。

### 7.2 实验结果（圣水 4 路口 × 5 机器人 × 24 小时）

| 项目 | 结果 |
|------|------|
| 跳变提取 | Precision 0.98, Recall 1.00, **F1 0.99** |
| $T_{cycle}$ 相对误差（白天） | 1.000 → **≤0.001**（贝叶斯） |
| color_err（白天，±30min) | **0.000 ~ 0.091** |
| 倒计时 MAE（后期到达） | **0.0 ~ 1.6 秒** |
| 贝叶斯 vs UKF | 贝叶斯全部指标占优 |

结果图（`experiment_results/<时间>/evaluation/`):

- `result_summary.png` — 各路口到达次数 vs 倒计时误差（学习曲线）
- `learner_convergence.png` — 贝叶斯（蓝）vs UKF（红）收敛对比
- `countdown_examples.png` — 三次到达的倒计时对比（学习进程）

---

## 8. 运行方式

```bash
./run.sh                     # 完整实验（生成→预测→分析），按时间戳归档
SEED=2024 ./run.sh           # 固定种子复现
python main.py               # 16 个测试（单元 + 端到端 + 因果性）
```

分步执行：

```bash
python -m crossphase_miner.cli.simulate --output-dir simulation
python -m crossphase_miner.cli.evaluate --data-dir simulation \
    --output-dir evaluation
```

结果保存在 `experiment_results/YYYYMMDD_HHMMSS/{simulation,evaluation}/`，
不覆盖历史实验。

---

## 9. 局限与未来计划

**局限**

- **稀疏样本时段**：夜晚一天只有 2~5 次到达，模型诚实地保持"不预测";
  随累计天数增加自然缓解。
- **相位漂移**：远离最近观测点时精度按 $\Delta T \cdot N$ 下降——这是
  固有限制，需要重新锚定（re-anchor)。
- **均匀到达假设**: $T_{red}$ 估计依赖"到达时刻在红灯内均匀分布"的假设。

**未来计划**

- **决策引擎恢复**(`core/decision.py`，当前整体注释）：用学到的模型把
  视觉确认门槛从 5 秒降到 3 秒，并在剩余绿灯不足时中止（ABORT）过街;
- 多日累计学习，强化夜间模型；
- 真实机器人数据接口。

---

## 附录 A. 目录结构

```
crossphase_miner/
├── core/            数据模型、TOD、跳变提取、学习器、（决策引擎：注释中）
├── simulation/      真值世界、机器人观测模拟器、圣水场景
├── pipeline/        IO、在线因果管线、评估指标
├── visualization/   绘图
└── cli/             simulate / evaluate 入口
main.py              16 个测试
run.sh               一键实验脚本
conception/motion/   概念演示 GIF 生成脚本
```
