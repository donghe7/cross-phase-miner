"""
Decision fusion engine for CrossPhaseMiner.

!!! TEMPORARILY DISABLED !!!
The decision fusion engine is not needed for now.  The whole implementation
is kept below as comments so it can be re-enabled later.  Callers use an
inline baseline rule instead (cross after N consecutive GREEN seconds).

Original design notes:

Combines visual signal observations with learned cycle models to make
safe crossing decisions for delivery robots.

The engine is stateful: feed it observations with ``observe`` and query
the current decision with ``decide``.  It tracks consecutive-color
counts internally, so callers never have to.

Decision hierarchy (safety-first):
1. RED observed: absolute WAIT (PREPARE only when a reliable model
   predicts green within ``prepare_threshold`` seconds).
2. UNKNOWN / FLASHING_GREEN observed: WAIT.
3. GREEN observed:
   a. Reliable model predicts remaining green <= required crossing time:
      ABORT.
   b. Otherwise GO once the color has been visually confirmed for
      ``confirm_threshold`` consecutive seconds.  The threshold is reduced
      (``reduced_confirm_threshold``) when a reliable model predicts enough
      remaining green; otherwise the strict default applies.
4. The model assists but never overrides the visual observation.
"""

# from __future__ import annotations
#
# from dataclasses import dataclass
# from typing import Dict, Optional
#
# from crossphase_miner.core.models import (
#     Action,
#     DecisionResult,
#     PeriodModel,
#     RiskLevel,
#     SignalColor,
#     SignalObservation,
# )
#
#
# @dataclass
# class _IntersectionState:
#     """Per-intersection observation state tracked by the engine."""
#     last_color: Optional[SignalColor] = None
#     last_confidence: float = 0.0
#     last_timestamp: float = 0.0
#     green_streak_start: Optional[float] = None
#     last_interval: float = 1.0
#
#     @property
#     def consecutive_green_seconds(self) -> float:
#         """How long GREEN has been observed continuously (seconds)."""
#         if self.last_color != SignalColor.GREEN or self.green_streak_start is None:
#             return 0.0
#         return (self.last_timestamp - self.green_streak_start) + self.last_interval
#
#
# class DecisionFusionEngine:
#     """Safety-critical decision fusion engine for crossing decisions."""
#
#     def __init__(
#         self,
#         tod_manager: Optional["object"] = None,
#         default_confirm_threshold: int = 5,
#         reduced_confirm_threshold: int = 3,
#         safe_crossing_margin: float = 3.0,
#         prepare_threshold: float = 5.0,
#     ) -> None:
#         """
#         Args:
#             tod_manager: Optional TODManager providing learned PeriodModels.
#                 Without it the engine falls back to pure visual confirmation.
#             default_confirm_threshold: Consecutive GREEN seconds required to
#                 cross without a reliable model (strict baseline).
#             reduced_confirm_threshold: Consecutive GREEN seconds required
#                 when a reliable model predicts sufficient remaining green.
#             safe_crossing_margin: Extra seconds on top of the crossing time.
#             prepare_threshold: Trigger PREPARE when green is predicted within
#                 this many seconds.
#         """
#         self.tod_manager = tod_manager
#         self.default_confirm_threshold = default_confirm_threshold
#         self.reduced_confirm_threshold = reduced_confirm_threshold
#         self.safe_crossing_margin = safe_crossing_margin
#         self.prepare_threshold = prepare_threshold
#         self._states: Dict[str, _IntersectionState] = {}
#
#     # -- Observation intake --------------------------------------------------
#
#     def observe(self, observation: SignalObservation) -> None:
#         """Record one observation and update consecutive-color tracking.
#
#         Consecutive-GREEN confirmation is measured in SECONDS (from
#         observation timestamps), so the same thresholds work at any
#         observation rate (1Hz, 10Hz, ...).
#         """
#         state = self._states.setdefault(
#             observation.intersection_id, _IntersectionState()
#         )
#         if (
#             state.last_timestamp
#             and observation.timestamp > state.last_timestamp
#             and observation.timestamp - state.last_timestamp <= 60.0
#         ):
#             state.last_interval = observation.timestamp - state.last_timestamp
#
#         if observation.color == SignalColor.GREEN:
#             if state.last_color != SignalColor.GREEN:
#                 state.green_streak_start = observation.timestamp
#         else:
#             state.green_streak_start = None
#         state.last_color = observation.color
#         state.last_confidence = observation.confidence
#         state.last_timestamp = observation.timestamp
#
#     def reset(self, intersection_id: Optional[str] = None) -> None:
#         """Clear tracked state (one intersection, or all)."""
#         if intersection_id is None:
#             self._states.clear()
#         else:
#             self._states.pop(intersection_id, None)
#
#     # -- Decision ------------------------------------------------------------
#
#     def decide(
#         self,
#         intersection_id: str,
#         current_time: Optional[float] = None,
#         safe_crossing_time: float = 8.0,
#     ) -> DecisionResult:
#         """
#         Make a crossing decision from the latest observation + cycle model.
#
#         Args:
#             intersection_id: Which intersection.
#             current_time: Unix timestamp; defaults to the last observation's.
#             safe_crossing_time: Time needed to cross safely (seconds).
#
#         Returns:
#             DecisionResult with action, confidence, reason, and threshold.
#         """
#         state = self._states.get(intersection_id)
#         if state is None or state.last_color is None:
#             return DecisionResult(
#                 action=Action.WAIT,
#                 confidence=0.0,
#                 reason="No observation yet - waiting",
#                 visual_confirm_required=self.default_confirm_threshold,
#                 predicted_green_time=float("inf"),
#                 predicted_green_remaining=-1.0,
#                 risk_level=RiskLevel.HIGH,
#             )
#
#         if current_time is None:
#             current_time = state.last_timestamp
#
#         color = state.last_color
#         color_confidence = state.last_confidence
#         consecutive_green = state.consecutive_green_seconds
#
#         model = self._get_model(intersection_id, current_time)
#         has_reliable_model = model is not None and model.is_reliable()
#         min_required = safe_crossing_time + self.safe_crossing_margin
#
#         # === 1. RED: absolute stop; PREPARE when green is imminent ===
#         if color == SignalColor.RED:
#             if has_reliable_model:
#                 remaining_red = model.predict_remaining_time(current_time, SignalColor.RED)
#                 if 0 < remaining_red <= self.prepare_threshold:
#                     return DecisionResult(
#                         action=Action.PREPARE,
#                         confidence=model.confidence,
#                         reason=f"RED signal, but green predicted in ~{remaining_red:.1f}s - prepare",
#                         visual_confirm_required=self.default_confirm_threshold,
#                         predicted_green_time=model.predict_next_green(current_time)[0],
#                         predicted_green_remaining=remaining_red,
#                         risk_level=RiskLevel.MEDIUM,
#                     )
#                 return DecisionResult(
#                     action=Action.WAIT,
#                     confidence=1.0,
#                     reason="RED signal detected - absolute stop",
#                     visual_confirm_required=self.default_confirm_threshold,
#                     predicted_green_time=model.predict_next_green(current_time)[0],
#                     predicted_green_remaining=remaining_red,
#                     risk_level=RiskLevel.HIGH,
#                 )
#             return DecisionResult(
#                 action=Action.WAIT,
#                 confidence=1.0,
#                 reason="RED signal detected - absolute stop",
#                 visual_confirm_required=self.default_confirm_threshold,
#                 predicted_green_time=float("inf"),
#                 predicted_green_remaining=-1.0,
#                 risk_level=RiskLevel.HIGH,
#             )
#
#         # === 2. UNKNOWN / FLASHING_GREEN: wait for a clear signal ===
#         if color in (SignalColor.UNKNOWN, SignalColor.FLASHING_GREEN):
#             return DecisionResult(
#                 action=Action.WAIT,
#                 confidence=0.5,
#                 reason=f"{color.name} signal - waiting for clear GREEN",
#                 visual_confirm_required=self.default_confirm_threshold,
#                 predicted_green_time=(
#                     model.predict_next_green(current_time)[0] if has_reliable_model else float("inf")
#                 ),
#                 predicted_green_remaining=-1.0,
#                 risk_level=RiskLevel.HIGH,
#             )
#
#         # === 3. GREEN ===
#         if color == SignalColor.GREEN:
#             required = self.default_confirm_threshold
#             remaining_green = -1.0
#
#             if has_reliable_model:
#                 remaining_green = model.predict_remaining_time(current_time, SignalColor.GREEN)
#
#                 if 0 <= remaining_green <= min_required:
#                     return DecisionResult(
#                         action=Action.ABORT,
#                         confidence=model.confidence,
#                         reason=(
#                             f"GREEN signal but only {remaining_green:.1f}s remaining "
#                             f"(<={min_required:.1f}s required) - abort crossing"
#                         ),
#                         visual_confirm_required=self.default_confirm_threshold,
#                         predicted_green_time=current_time + remaining_green,
#                         predicted_green_remaining=remaining_green,
#                         risk_level=RiskLevel.HIGH,
#                     )
#                 required = self.reduced_confirm_threshold
#
#             if consecutive_green >= required:
#                 risk = RiskLevel.LOW if has_reliable_model else RiskLevel.MEDIUM
#                 confidence = (
#                     model.confidence * color_confidence
#                     if has_reliable_model
#                     else color_confidence * 0.5
#                 )
#                 return DecisionResult(
#                     action=Action.GO,
#                     confidence=confidence,
#                     reason=(
#                         f"GREEN confirmed {consecutive_green:.1f}s "
#                         f"(>={required}s required) - cross"
#                     ),
#                     visual_confirm_required=required,
#                     predicted_green_time=(
#                         current_time + remaining_green if remaining_green >= 0 else float("inf")
#                     ),
#                     predicted_green_remaining=remaining_green,
#                     risk_level=risk,
#                 )
#
#             return DecisionResult(
#                 action=Action.WAIT,
#                 confidence=0.5,
#                 reason=(
#                     f"GREEN but only {consecutive_green:.1f}s confirmed "
#                     f"(<{required}s required) - keep confirming"
#                 ),
#                 visual_confirm_required=required,
#                 predicted_green_time=(
#                     current_time + remaining_green if remaining_green >= 0 else float("inf")
#                 ),
#                 predicted_green_remaining=remaining_green,
#                 risk_level=RiskLevel.HIGH,
#             )
#
#         # Fallback (should not reach).
#         return DecisionResult(
#             action=Action.WAIT,
#             confidence=0.3,
#             reason="Unhandled state - default wait",
#             visual_confirm_required=self.default_confirm_threshold,
#             predicted_green_time=float("inf"),
#             predicted_green_remaining=-1.0,
#             risk_level=RiskLevel.HIGH,
#         )
#
#     def _get_model(
#         self, intersection_id: str, current_time: float
#     ) -> Optional[PeriodModel]:
#         """Get the PeriodModel for an intersection at a given time."""
#         if self.tod_manager is None:
#             return None
#         return self.tod_manager.get_model(intersection_id, current_time)
