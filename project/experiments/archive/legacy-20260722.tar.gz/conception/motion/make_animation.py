#!/usr/bin/env python3
"""
CrossPhaseMiner concept demo animation (GIF).

Story: a delivery robot visits the same Seongsu intersection five times in
one day.  The traffic light shows the TRUE countdown (like real Korean
pedestrian signals); the robot shows its PREDICTED countdown.  Watch the
prediction improve round by round as the Bayesian learner sees more phase
transitions.

All predictions come from the project's own BayesianPeriodLearner fed with
transitions extracted from the robot's noisy observations - no hand-tuned
fake data.  (For the demo, raw model predictions are shown even in early
rounds; the production system additionally gates predictions behind a
reliability threshold.)

Output: conception/motion/crossphase_concept.gif

Usage:
    python conception/motion/make_animation.py
"""

from __future__ import annotations

import os
import sys
from typing import List, Optional

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np
from matplotlib.animation import FuncAnimation, PillowWriter

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from crossphase_miner.core.learners import BayesianPeriodLearner
from crossphase_miner.core.models import PeriodModel, SignalColor
from crossphase_miner.core.transitions import extract_transitions
from crossphase_miner.simulation.robot import RobotArrivalSimulator
from crossphase_miner.simulation.scenarios import (
    build_seongsu_world,
    default_base_time,
)

OUT_DIR = os.path.dirname(os.path.abspath(__file__))
OUT_GIF = os.path.join(OUT_DIR, "crossphase_concept.gif")

IID = "seongsu_station"  # day plan: cycle 150s, red 119s, green 31s

plt.rcParams["font.family"] = "NanumSquare_ac"
plt.rcParams["axes.unicode_minus"] = False


# ---------------------------------------------------------------------------
# 1. Simulate five arrivals and train the learner round by round (causal)
# ---------------------------------------------------------------------------

def build_rounds():
    world = build_seongsu_world()
    sim = RobotArrivalSimulator(world, random_seed=7)

    base = default_base_time()
    # RG transitions are spaced 5-7 cycles apart (750s = 5x150, 1050s =
    # 7x150; gcd of the gaps is exactly the true cycle 150s).  Large gaps
    # would amplify tiny T_cycle errors into big phase drifts (error =
    # ΔT x cycles), hiding the learning progress.
    waits = [89.0, 39.0, 109.0, 29.0, 69.0]
    rg0 = base + 7.0 * 3600 + 119.0  # first RED->GREEN at 07:01:59
    rg_offsets = [0.0, 750.0, 1800.0, 2550.0, 3600.0]
    arrival_times = [rg0 + off - w for off, w in zip(rg_offsets, waits)]

    learner = BayesianPeriodLearner()
    rounds: List[dict] = []

    for r, t_arr in enumerate(arrival_times, 1):
        obs = sim.simulate_arrival(
            IID, t_arr, f"robot_{r:03d}", misclass_prob=0.03
        )

        # Model in effect DURING this arrival (trained on past rounds only).
        model_before = learner.get_model()

        # Ground truth + prediction per second.
        secs, gt, pred = [], [], []
        for o in obs[::10]:  # 10Hz -> 1s
            t = o.timestamp
            secs.append(t - obs[0].timestamp)
            # True countdown.
            if world.color_at(IID, t) == SignalColor.GREEN:
                gt.append(0.0)
            else:
                ng = world.next_color_time(IID, t, SignalColor.GREEN)
                gt.append(ng - t if ng is not None else np.nan)
            # Predicted countdown (raw model output; None if untrained,
            # and discarded on a model/vision conflict - vision wins).
            pred.append(_predicted_countdown(model_before, o))

        gt_a = np.array(gt, dtype=float)
        pred_a = np.array(pred, dtype=float)
        valid = (
            (gt_a > 0.5)
            & np.isfinite(pred_a)
            & np.array([o.color == SignalColor.RED for o in obs[::10]])
        )
        mae = (
            float(np.mean(np.abs(pred_a[valid] - gt_a[valid])))
            if np.any(valid)
            else np.nan
        )

        rounds.append({
            "idx": r,
            "obs": obs,
            "secs": np.array(secs),
            "gt": gt_a,
            "pred": pred_a,
            "mae": mae,
            "model": model_before,
        })

        # Learn from this round's observations (after the arrival).
        for tr in extract_transitions(obs):
            learner.update(tr)

    return world, rounds


def _raw_next_green(model: PeriodModel, t: float) -> Optional[float]:
    """Next-green prediction from model params, without the reliability gate."""
    if model.sample_count < 1 or model.T_cycle <= 0:
        return None
    phase = (t - model.phi_offset) % model.T_cycle
    if phase < model.T_red:
        wait = model.T_red - phase
    else:
        wait = (model.T_cycle - phase) + model.T_red
    return t + wait


def _predicted_countdown(model: PeriodModel, obs) -> float:
    """
    Predicted seconds-to-green for one observation (demo version of the
    pipeline rule):
    - GREEN observed: trivially 0.
    - No model yet / model-vision color conflict: NaN (vision wins).
    """
    if obs.color == SignalColor.GREEN:
        return 0.0
    if model.sample_count < 1 or model.T_cycle <= 0:
        return np.nan
    phase = (obs.timestamp - model.phi_offset) % model.T_cycle
    model_says_red = phase < model.T_red
    if model_says_red != (obs.color == SignalColor.RED):
        return np.nan  # conflict: trust vision, no model countdown
    next_green = _raw_next_green(model, obs.timestamp)
    if next_green is None:
        return np.nan
    return max(0.0, next_green - obs.timestamp)


# ---------------------------------------------------------------------------
# 2. Animation frames
# ---------------------------------------------------------------------------

def main() -> None:
    print("Simulating 5 rounds with the project's own learner...")
    world, rounds = build_rounds()
    for r in rounds:
        m = r["model"]
        mae = f"{r['mae']:.1f}s" if np.isfinite(r["mae"]) else "-"
        print(f"  round {r['idx']}: wait={r['secs'][-1]:.0f}s "
              f"model(T={m.T_cycle:.0f}, T_red={m.T_red:.0f}, n={m.sample_count}) "
              f"MAE={mae}")

    frames = [
        (r_idx, s_idx)
        for r_idx, r in enumerate(rounds)
        for s_idx in range(len(r["secs"]))
    ]
    print(f"  {len(frames)} frames")

    fig = plt.figure(figsize=(10, 6.2), dpi=100)
    fig.patch.set_facecolor("white")
    gs = fig.add_gridspec(2, 1, height_ratios=[1.0, 1.4], hspace=0.30)
    ax_scene = fig.add_subplot(gs[0])
    ax_plot = fig.add_subplot(gs[1])

    def draw_scene(ax, rd, s_idx):
        ax.clear()
        ax.set_xlim(0, 10)
        ax.set_ylim(0, 3.2)
        ax.axis("off")

        t = rd["obs"][0].timestamp + rd["secs"][s_idx]
        true_color = world.color_at(IID, t)
        true_left = rd["gt"][s_idx]
        pred_left = rd["pred"][s_idx]

        # Road + crosswalk
        ax.plot([0, 10], [0.55, 0.55], color="#555", lw=2)
        for i in range(5):
            ax.add_patch(mpatches.Rectangle(
                (7.2 + i * 0.35, 0.3), 0.2, 0.5, color="#ccc"))

        # Traffic light with TRUE countdown (like real pedestrian signals)
        light_color = "#d62728" if true_color == SignalColor.RED else "#2ca02c"
        ax.add_patch(mpatches.FancyBboxPatch(
            (7.5, 1.15), 0.8, 1.45, boxstyle="round,pad=0.03,rounding_size=0.08",
            facecolor="#222", edgecolor="#555", lw=2))
        ax.add_patch(plt.Circle((7.9, 2.15), 0.3, color=light_color,
                                ec="black", lw=1.5, zorder=3))
        ax.add_patch(plt.Circle((7.9, 1.5), 0.3, color="#3a3a3a",
                                ec="black", lw=1.5, zorder=3))
        if true_color == SignalColor.RED and np.isfinite(true_left):
            ax.text(7.9, 0.85, f"{true_left:.0f}", ha="center", va="center",
                    fontsize=20, fontweight="bold", color="#d62728")
            ax.text(7.9, 2.85, "실제", ha="center", fontsize=10, color="#666")
        else:
            ax.text(7.9, 0.85, "GO", ha="center", va="center",
                    fontsize=16, fontweight="bold", color="#2ca02c")

        # Robot
        ax.add_patch(plt.Circle((1.5, 0.8), 0.3, color="#1f77b4",
                                ec="black", lw=1.5, zorder=3))
        ax.text(1.5, 0.8, "R", ha="center", va="center", color="white",
                fontsize=12, fontweight="bold", zorder=4)

        # Robot's PREDICTED countdown
        if not np.isfinite(pred_left):
            pred_text = "예측: ?"
            bubble = "#f0f0f0"
        elif pred_left > 0.5:
            pred_text = f"예측: {pred_left:.0f}초"
            bubble = "#dcefff"
        else:
            pred_text = "녹색신호! 건너기"
            bubble = "#d9ead3"
        ax.add_patch(mpatches.FancyBboxPatch(
            (2.4, 1.45), 3.2, 0.9, boxstyle="round,pad=0.08,rounding_size=0.15",
            facecolor=bubble, edgecolor="#888", lw=1.2))
        ax.text(4.0, 1.9, pred_text, ha="center", va="center",
                fontsize=14, fontweight="bold", color="#222")

        # Round counter + previous round error + learned model
        ax.text(0.2, 2.9, f"도착 #{rd['idx']} / {len(rounds)}",
                fontsize=13, fontweight="bold", color="#111")
        if rd["idx"] > 1:
            prev = rounds[rd["idx"] - 2]["mae"]
            if np.isfinite(prev):
                ax.text(0.2, 2.5, f"이전 도착 예측 오차: {prev:.1f}초",
                        fontsize=10, color="#666")
        m = rd["model"]
        if m.sample_count > 0:
            ax.text(0.2, 1.15,
                    f"학습: T={m.T_cycle:.0f}s, R={m.T_red:.0f}s (실제 150/119s)",
                    fontsize=8, color="#888")

    def draw_plot(ax, rd, s_idx):
        ax.clear()
        secs, gt, pred = rd["secs"], rd["gt"], rd["pred"]
        ax.plot(secs, gt, "--", color="darkgreen", lw=1.5, alpha=0.4,
                label="실제 (ground truth)")
        k = s_idx + 1
        ax.plot(secs[:k], gt[:k], "--", color="darkgreen", lw=2.2)
        ax.plot(secs[:k], pred[:k], "o-", color="#1f77b4", lw=1.6,
                markersize=2.0, label="모델 예측")
        ax.axhline(0, color="green", ls=":", alpha=0.4)
        ax.set_xlim(0, secs[-1] * 1.02)
        ymax = max(np.nanmax(gt) * 1.15 + 2, 20)
        ax.set_ylim(-ymax * 0.03, ymax)
        ax.set_xlabel("도착 후 경과 시간 (초)")
        ax.set_ylabel("녹색신호까지 (초)")
        ax.grid(True, ls="--", alpha=0.4)
        ax.legend(loc="upper right", fontsize=9)

    def update(fi):
        r_idx, s_idx = frames[fi]
        rd = rounds[r_idx]
        draw_scene(ax_scene, rd, s_idx)
        draw_plot(ax_plot, rd, s_idx)
        fig.suptitle(
            "CrossPhaseMiner: 반복 관측으로 신호등 주기를 학습하는 배달 로봇",
            fontsize=13, fontweight="bold",
        )
        return []

    ani = FuncAnimation(fig, update, frames=len(frames), interval=50)
    print(f"Writing {OUT_GIF} ...")
    ani.save(OUT_GIF, writer=PillowWriter(fps=20))
    plt.close(fig)
    print(f"Done: {OUT_GIF}")


if __name__ == "__main__":
    main()
