"""
Robot observation simulator.

Simulates a delivery robot arriving at an intersection.  The robot behaves
in one of two modes:

- NORMAL mode (daily delivery): records the signal color at ``obs_rate_hz``
  (default 10Hz) while waiting, and crosses after ``confirm_seconds``
  consecutive GREEN seconds (inline baseline rule; the decision fusion
  engine is temporarily disabled, see crossphase_miner/core/decision.py).
- SCOUT mode (learning): the robot does NOT cross at the first green - it
  waits through a COMPLETE cycle (RG -> GR -> RG or GR -> RG -> GR).  One
  scout wait measures T_green, T_red and T_cycle exactly, replacing ~10
  ordinary arrivals of sparse learning.

The mode is chosen per arrival: SCOUT when the robot's own cycle model for
the intersection is not reliable yet (and scout_mode is enabled), NORMAL
otherwise.  The simulator keeps its own per-intersection learner purely to
make that decision.

Ground-truth transitions that occurred during the wait window are recorded
separately for evaluation export.
"""

from __future__ import annotations

from enum import Enum
from typing import Dict, List, Optional

import numpy as np

# NOTE: the decision fusion engine is temporarily disabled
# (see crossphase_miner/core/decision.py).  The robot crosses with an
# inline baseline rule instead: N consecutive seconds of GREEN.
# from crossphase_miner.core.decision import DecisionFusionEngine
from crossphase_miner.core.learners import BayesianPeriodLearner
from crossphase_miner.core.models import (
    PhaseTransition,
    SignalColor,
    SignalObservation,
)
from crossphase_miner.core.transitions import (
    extract_transitions,
    has_full_cycle,
)
from crossphase_miner.simulation.world import SignalWorld

# Upper bound for a scout wait: comfortably covers two cycles of any
# realistic fixed-time plan.
SCOUT_TIMEOUT_SECONDS = 450


class RobotMode(Enum):
    """Behavior mode of the robot for one arrival."""
    NORMAL = "normal"  # daily delivery: cross at the first confirmed green
    SCOUT = "scout"  # learning: wait a complete cycle to measure it exactly


class RobotArrivalSimulator:
    """Generates noisy discrete observations of a SignalWorld."""

    def __init__(
        self,
        world: SignalWorld,
        random_seed: int = 42,
        obs_rate_hz: float = 10.0,
        confirm_seconds: float = 5.0,
        scout_mode: bool = False,
    ) -> None:
        """
        Args:
            world: Ground-truth signal world.
            random_seed: Seed for the noise generator.
            obs_rate_hz: Observation rate in Hz (default 10).
            confirm_seconds: Consecutive GREEN seconds before crossing in
                NORMAL mode (inline baseline, decision engine disabled).
            scout_mode: Master switch for the scout capability.  When
                enabled, EVERY arrival automatically becomes a SCOUT
                arrival whenever the robot's model for the intersection is
                not reliable yet, and a NORMAL arrival once it is.
        """
        self.world = world
        self.rng = np.random.RandomState(random_seed)
        self.obs_rate_hz = float(obs_rate_hz)
        self.confirm_seconds = float(confirm_seconds)
        self.scout_mode = bool(scout_mode)
        self._true_transitions: List[PhaseTransition] = []
        # Per-(intersection, TOD period) "brain": learns from each
        # arrival's transitions and drives the automatic SCOUT/NORMAL
        # mode selection.  Splitting by TOD period means a verified day
        # model stays valid when night comes (and vice versa) - no
        # mismatch/invalidate churn at period switches.
        self._learners: Dict[tuple, BayesianPeriodLearner] = {}
        self._mismatch_streak: Dict[tuple, int] = {}
        self.scout_wait_count: int = 0

    # -- Scout bookkeeping ---------------------------------------------------

    def _model_reliable(self, intersection_id: str, timestamp: float) -> bool:
        period = self.world.classify_tod(timestamp)
        learner = self._learners.get((intersection_id, period))
        return learner is not None and learner.get_model().is_reliable()

    def choose_mode(
        self, intersection_id: str, arrival_time: float
    ) -> RobotMode:
        """
        Automatic per-arrival mode selection.

        SCOUT iff the scout capability is enabled AND the cycle model for
        this (intersection, TOD period) is not reliable yet; otherwise
        NORMAL.

        A scout wait must fit inside the CURRENT TOD period: if a period
        boundary falls within the scout window, the measurement would mix
        two different signal plans, so the robot stays in NORMAL mode this
        time (a real robot knows the TOD schedule from the clock).
        """
        if not self.scout_mode or self._model_reliable(
            intersection_id, arrival_time
        ):
            return RobotMode.NORMAL
        from crossphase_miner.core.tod import next_period_boundary
        boundary = next_period_boundary(
            arrival_time, self.world.period_configs
        )
        if boundary - arrival_time < SCOUT_TIMEOUT_SECONDS * 0.75:
            return RobotMode.NORMAL
        return RobotMode.SCOUT

    def _learn_from_episode(
        self, intersection_id: str, observations: List[SignalObservation]
    ) -> None:
        """Update the robot's own learner with this episode's transitions."""
        transitions = extract_transitions(observations)
        if not transitions:
            return
        ep_period = self.world.classify_tod(observations[0].timestamp)
        key = (intersection_id, ep_period)
        learner = self._learners.setdefault(key, BayesianPeriodLearner())

        # Mismatch check on a verified model: if observed transitions
        # persistently contradict it (signal retimed / plan changed), drop
        # the verification - the next arrival auto-enters SCOUT mode.
        # The streak accumulates across episodes (one episode may contain
        # a single transition).
        if learner._cycle_verified:
            model = learner.get_model()
            ep_mismatches = sum(
                1 for t in transitions
                if model.transition_phase_error(t.timestamp, t.to_color) > 10.0
            )
            self._mismatch_streak[key] = (
                self._mismatch_streak.get(key, 0) + ep_mismatches
                if ep_mismatches > 0
                else 0
            )
            if self._mismatch_streak[key] >= 2:
                learner.invalidate()
                self._mismatch_streak[key] = 0

        for t in transitions:
            # Skip transitions across a TOD boundary (neighboring plan).
            if self.world.classify_tod(t.timestamp) != ep_period:
                continue
            learner.update(t)
        # Verify only when the complete cycle belongs to ONE TOD period.
        if has_full_cycle(transitions):
            periods_seen = {
                self.world.classify_tod(t.timestamp) for t in transitions
            }
            if len(periods_seen) == 1:
                learner.mark_cycle_verified()

    # -- Arrival simulation ----------------------------------------------------

    def simulate_arrival(
        self,
        intersection_id: str,
        arrival_time: float,
        robot_id: str = "robot_001",
        misclass_prob: float = 0.03,
        max_wait_seconds: int = 300,
    ) -> List[SignalObservation]:
        """
        Simulate one robot arrival; return observations until crossing.

        NORMAL mode: the robot crosses after ``confirm_seconds`` consecutive
        GREEN seconds, or gives up after ``max_wait_seconds``.

        SCOUT mode (auto-selected when the model is unreliable): the robot
        waits until it has observed a complete cycle (then crosses on the
        next confirmed GREEN), or until SCOUT_TIMEOUT_SECONDS.
        """
        if intersection_id not in self.world.intersections:
            raise KeyError(f"Intersection '{intersection_id}' not registered.")

        mode = self.choose_mode(intersection_id, arrival_time)
        if mode is RobotMode.SCOUT:
            self.scout_wait_count += 1
            max_wait_seconds = max(max_wait_seconds, SCOUT_TIMEOUT_SECONDS)

        dt = 1.0 / self.obs_rate_hz
        n_steps = int(round(max_wait_seconds * self.obs_rate_hz))
        observations: List[SignalObservation] = []

        # Inline baseline crossing rule (decision engine disabled):
        # track the continuous GREEN streak in seconds.
        green_streak_start: Optional[float] = None

        for step in range(n_steps):
            ts = arrival_time + step * dt
            true_color = self.world.color_at(intersection_id, ts)

            if self.rng.random() < misclass_prob:
                obs_color = (
                    SignalColor.GREEN
                    if true_color == SignalColor.RED
                    else SignalColor.RED
                )
                confidence = self.rng.uniform(0.55, 0.75)
            else:
                obs_color = true_color
                confidence = self.rng.uniform(0.88, 0.99)

            obs = SignalObservation(
                intersection_id=intersection_id,
                timestamp=ts,
                color=obs_color,
                confidence=confidence,
                robot_id=robot_id,
            )
            observations.append(obs)

            # --- disabled: decision fusion engine ---
            # self.engine.observe(obs)
            # decision = self.engine.decide(intersection_id, ts)
            # if decision.action == Action.GO:
            #     break
            if obs.color == SignalColor.GREEN:
                if green_streak_start is None:
                    green_streak_start = ts
                green_ok = (ts - green_streak_start) + dt >= self.confirm_seconds
            else:
                green_streak_start = None
                green_ok = False

            if not green_ok:
                continue

            if mode is RobotMode.SCOUT:
                # Cross only after the complete cycle has been observed.
                if step % 10 == 0 or step == n_steps - 1:
                    if has_full_cycle(extract_transitions(observations)):
                        break
            else:  # NORMAL: cross at the first confirmed green.
                break

        self._learn_from_episode(intersection_id, observations)

        # Record TRUE transitions that happened during the wait window.
        end_time = arrival_time + len(observations) * dt
        for ts, from_color, to_color in self.world.true_transitions_in_window(
            intersection_id, arrival_time, end_time
        ):
            self._true_transitions.append(
                PhaseTransition(
                    intersection_id=intersection_id,
                    timestamp=ts,
                    from_color=from_color,
                    to_color=to_color,
                    robot_id=robot_id,
                )
            )

        return observations

    def get_true_transitions(
        self, intersection_id: Optional[str] = None
    ) -> List[PhaseTransition]:
        """TRUE transitions recorded so far (optionally for one intersection)."""
        if intersection_id is None:
            return list(self._true_transitions)
        return [
            t for t in self._true_transitions
            if t.intersection_id == intersection_id
        ]

    def clear_history(self) -> None:
        """Drop all recorded true transitions."""
        self._true_transitions.clear()
