# CrossPhaseMiner

**Signal Cycle Learning System for Delivery Robots**

CrossPhaseMiner learns pedestrian crossing signal timing patterns from sparse,
noisy visual observations made by delivery robots, then uses the learned models
to assist crossing decisions.

---

## Overview

### Problem

Delivery robots navigating urban environments must cross pedestrian crosswalks
safely. The conservative baseline — "see GREEN for 5 consecutive seconds before
crossing" — causes unnecessary delays.

### Insight

Urban traffic signals follow **Time-of-Day (TOD) fixed-cycle plans**: within
each period of the day, an intersection repeats the same cycle. A robot that
observes a signal multiple times can learn the cycle and predict future states.

The Seongsu demonstration uses a **day / night** split.  A field observation
constraints the scenario: **the GREEN duration of a signal is constant
across TOD periods; only the RED duration changes** (e.g. intersection 1:
green 31s / red 119s / cycle 150s in the evening, green 31s / red 109s /
cycle 140s after midnight):

| Period | Hours       | Cycle   | Red     | Green (constant) |
|--------|-------------|---------|---------|------------------|
| Day    | 06:00-22:00 | 150-170s| 119-138s| 28-33s           |
| Night  | 22:00-06:00 | 140-160s| 109-128s| (same as day)    |

### Solution

1. Robots record discrete signal observations at **10Hz** while waiting.
2. Phase transitions (RED→GREEN) are extracted with de-bouncing and
   confidence filtering.
3. Cycle parameters (**T_cycle**, **T_red**, **phi_offset**) are learned
   online per (intersection, TOD period) — a Bayesian learner and a UKF
   learner run in parallel for comparison.
4. (Disabled for now) A safety-first decision engine fuses model
   predictions with real-time visual observations.

### Design principles (what a redesign fixed)

- **No ground-truth leakage.** Learners start from a generic prior
  (`T_cycle ~ N(120, 40²)`); ground truth is used *only* to score results.
- **Causal online pipeline.** Arrivals are replayed in time order: each
  arrival is first scored with the current model, *then* mined for
  transitions. No future information ever influences an evaluation point.
- **One phase convention.** `PeriodModel.phi_offset` is always the start of
  a red phase (cycle origin); `phase(t) = (t - phi_offset) % T_cycle` is red
  when `< T_red`. No coordinate conversions anywhere else.
- **Time-based, not frame-based.** Confirmation thresholds are measured in
  seconds, so behavior is identical at any observation rate.

---

## Architecture

```
crossphase_miner/
├── core/                        # Pure algorithms, no I/O
│   ├── models.py                # Data models + phase convention
│   ├── tod.py                   # TOD classification (single implementation) + TODManager
│   ├── transitions.py           # De-bounced transition extraction
│   ├── learners.py              # BayesianPeriodLearner + UKFPeriodLearner
│   └── decision.py              # DecisionFusionEngine (TEMPORARILY DISABLED)
├── simulation/
│   ├── world.py                 # SignalWorld: ground-truth signal state
│   ├── robot.py                 # RobotArrivalSimulator: noisy 10Hz observations
│   └── scenarios.py             # Seongsu scenario (4 intersections, 5 robots)
├── pipeline/
│   ├── io.py                    # CSV/JSON loading & export
│   ├── online.py                # OnlinePipeline: causal replay (decide → score → learn)
│   └── evaluation.py            # Metrics (ground truth used ONLY here)
├── visualization/
│   └── plots.py                 # Matplotlib visualizations
├── cli/
│   ├── simulate.py              # Data generation entry point
│   └── evaluate.py              # Evaluation entry point
└── utils/
    └── math_utils.py            # Gaussian product, UKF sigma points, KST time

crossphase_miner/
├── ...                          # v1 package (sparse-sample learning)
└── main.py                      # v1 test suite

crossphase_miner_2/              # v2 project (adds SCOUT/NORMAL modes)
├── crossphase_miner/            # v2 package
└── main.py                      # v2 test suite (incl. scout tests)

run.sh                           # Unified runner: ./run.sh v1|v2 [--scout] | v1|v2 test
```

### Data flow

```
SignalWorld (truth)
      │  RobotArrivalSimulator: 10Hz noisy observations
      ▼
observations.csv ──► OnlinePipeline (per arrival, in time order):
                        1. score current model's countdown vs SignalWorld
                        2. extract_transitions → Bayesian + UKF update
                     ▼
              evaluation.py metrics + plots
```

> **Note**: the decision fusion engine (`core/decision.py`) is currently
> **disabled** (the implementation is kept as comments in the file).  The
> robot simulator crosses with an inline baseline rule (5 consecutive
> GREEN seconds), and the pipeline replays arrivals without per-second
> decisions.  The design notes below are kept for when it is re-enabled.

---

## Algorithms

### Transition extraction (`core/transitions.py`)

- **De-bouncing**: a color change is confirmed only after the new color
  persists for `min_duration` seconds (default 2.0).
- **Confidence filtering**: observations below `min_confidence` (default
  0.8) are ignored — vision misclassifications come with low confidence and
  would otherwise create spurious transitions in pairs.
- **Backdating**: confirmed transitions are timestamped at the first sample
  of the new color, removing the confirmation delay.

### Bayesian period learner (`core/learners.py`)

Estimates three parameters from RED→GREEN transitions:

- **T_cycle**: pairwise RG time differences are integer multiples of the
  period. A fixed-range periodogram scores candidates by inlier count with
  a soft prior tie-breaker. The **sub-harmonic ambiguity** (T/2, T/3, ...
  fit RG times exactly as well as T) is resolved by a hard lower bound from
  observed waiting times: a wait of W seconds rules out any period below W.
- **T_red**: for an arrival during red, the remaining wait is a sample of
  `Uniform(0, T_red)`; the estimator is `max(samples) * (n+1)/n` (unbiased
  uniform-bound estimate), fused with a weak red-fraction prior.
- **phi_offset**: the latest RG transition marks phase position T_red, so
  `phi_offset = t_rg - T_red`.

The posterior is **recomputed from scratch** (prior + full-data estimate)
on every update, so early ambiguous estimates can neither lock the search
range nor freeze the posterior.

### Shared-green constraint (TOD fusion)

Field observation: **T_green is constant across TOD periods; only T_red
changes.**  Each period's learner votes for the shared green with its own
`T_cycle - T_red` (inverse-variance weighted); the pooled T_green is then
applied back:

```
T_red(period) = T_cycle(period) - T_green(shared)
```

Since T_cycle is estimated far more accurately than T_red (periodogram vs.
waiting-time statistics), this lets data-scarce periods (e.g. night, with
only a handful of transitions) inherit a precise red duration.

### UKF period learner

State `x = [T_cycle, T_red, phi_offset]`, random-walk process model,
measurement `h(x, k) = phi_offset + T_red + k·T_cycle` with the same
wait-time lower bound applied as a state constraint. Runs in parallel with
the Bayesian learner so their convergence curves can be compared. In
practice the Bayesian learner converges faster and more reliably: the UKF's
cycle-index computation suffers from the same aliasing and has no global
periodogram to fall back on.

### Decision fusion engine (`core/decision.py`) — currently disabled

> The engine is commented out for now; this section describes the design it
> will implement when re-enabled.

Stateful: `engine.observe(obs)` tracks the continuous GREEN duration (in
seconds), `engine.decide(iid, time)` returns the action.

| Condition | Action | Confirm | Risk |
|-----------|--------|---------|------|
| RED observed | **WAIT** | 5s | HIGH |
| RED + reliable model predicts green ≤ 5s | PREPARE | 5s | MEDIUM |
| UNKNOWN / FLASHING_GREEN | WAIT | 5s | HIGH |
| GREEN, no reliable model | GO after **5s** confirmed | 5s | MEDIUM |
| GREEN + model: remaining ≤ required (8s+3s) | **ABORT** | 5s | HIGH |
| GREEN + model: remaining > required | GO after **3s** confirmed | 3s | LOW |

The model **assists** but never overrides the visual observation: RED always
stops the robot, and on a model/vision conflict vision wins.

---

## Usage

### One-command experiment (recommended)

```bash
./run.sh v1                        # v1: sparse-sample learning pipeline
./run.sh v2 --scout                # v2: SCOUT/NORMAL modes (recommended)
./run.sh v1 test                   # run the v1 test suite
./run.sh v2 test                   # run the v2 test suite
SEED=2024 ./run.sh v2 --scout      # fixed seed for reproduction
```

Runs all three steps - data generation, prediction, analysis - and stores
everything in a versioned, timestamped folder:

```
experiment_results/<v1|v2>/YYYYMMDD_HHMMSS/
├── simulation/                    # step 1: generated data (input)
│   ├── observations.csv           # robot observations (10Hz, noisy)
│   ├── groundtruth_configs.json   # TRUE TOD signal parameters
│   ├── groundtruth_transitions.csv # TRUE phase transitions
│   └── simulation_summary.json    # simulation statistics
└── evaluation/                    # step 2+3: prediction + analysis
    ├── observed_transitions.csv   # transitions estimated from observations
    ├── evaluation.log             # full analysis log
    ├── result_summary.png         # countdown MAE vs. arrival number
    ├── learner_convergence.png    # Bayesian vs. UKF convergence
    └── countdown_examples.png     # countdown comparison across arrivals
```

### Step by step

```bash
# 1. Generate Seongsu simulation data
python -m crossphase_miner.cli.simulate --robots 5 --misclass 0.03 \
    --output-dir simulation

# 2. Run prediction + analysis
python -m crossphase_miner.cli.evaluate --data-dir simulation \
    --output-dir evaluation
```

(For v2, run the same commands from inside `crossphase_miner_2/`, adding
`--scout` to enable scout mode.)

The evaluation runs the online causal pipeline and writes a compact set of
outputs (all under `--output-dir`; the data directory is never modified):

- `observed_transitions.csv` - signal transitions estimated from robot
  observations (the counterpart of `groundtruth_transitions.csv`), plus
  the extraction quality report (P/R/F1) on stdout
- `result_summary.png` - the end-to-end result: countdown MAE per arrival
  for every intersection, titled with learned vs. true cycle parameters
- `learner_convergence.png` - Bayesian vs. UKF convergence side by side
- `countdown_examples.png` - countdown to green (predicted vs. ground
  truth) for three example arrivals at one intersection - first
  predictable / middle / last - showing the learning progress

### Run tests

```bash
./run.sh v1 test    # 16 tests (unit + end-to-end + causality)
./run.sh v2 test    # 18 tests (adds scout-mode and re-scout tests)
```

15 tests: unit tests for every module plus end-to-end tests, including a
causality test proving that predictions during an arrival only use past
data.  (The 5 decision-engine tests are commented out while the engine is
disabled.)

### Use as a library

```python
from crossphase_miner.core.learners import BayesianPeriodLearner
from crossphase_miner.core.tod import TODManager

learner = BayesianPeriodLearner()          # generic honest prior
for transition in transitions:
    model = learner.update(transition)

tod = TODManager()
tod.update_model("intersection_001", now, model)

model = tod.get_model("intersection_001", now)
next_green, confidence = model.predict_next_green(now)
```

---

## Installation

```bash
pip install -r requirements.txt
```

Requirements: Python 3.10+, numpy, matplotlib.

## License

MIT License
